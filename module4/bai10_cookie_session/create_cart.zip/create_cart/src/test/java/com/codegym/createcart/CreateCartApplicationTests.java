package com.codegym.createcart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreateCartApplicationTests {

    @Test
    void contextLoads() {
    }

}
