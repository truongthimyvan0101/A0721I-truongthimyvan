package com.codegym.createcart.service;

import com.codegym.createcart.model.Cart;

public interface CartService {

}
