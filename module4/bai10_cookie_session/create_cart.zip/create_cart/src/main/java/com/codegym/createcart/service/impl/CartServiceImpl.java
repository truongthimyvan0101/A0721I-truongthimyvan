package com.codegym.createcart.service.impl;

import com.codegym.createcart.model.Cart;
import com.codegym.createcart.repository.CartRepository;
import com.codegym.createcart.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CartServiceImpl implements CartService {
}
